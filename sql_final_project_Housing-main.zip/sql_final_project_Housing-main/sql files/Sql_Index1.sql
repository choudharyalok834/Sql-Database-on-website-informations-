create index flat_name_index
on flat_names (Flat_Id);


