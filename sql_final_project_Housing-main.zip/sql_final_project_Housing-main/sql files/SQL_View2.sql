delimiter //
create procedure Building_Features_view()
begin
	select * from building_view;
end