Create index flat_overview 
on flat_overview(Flat_Id);
